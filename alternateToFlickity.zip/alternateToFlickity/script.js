angular.module('app',[])
.controller('ctrl', function($scope){
    $scope.showSlide1 = true;
    $scope.showSlide2 = false;
    $scope.showSlide3 = false;

    $scope.animate1stSlide = 'animated fadeInRight';
    $scope.bring1stSlide = function(direction){
        $scope.showSlide1 = true;
        $scope.showSlide2 = false;
        $scope.showSlide3 = false;
        if(direction === "from-left" ){
            $scope.animate1stSlide = 'animated fadeInLeft'
        }else{
            $scope.animate1stSlide = 'animated fadeInRight'
        }
    };

    $scope.animate2ndSlide = 'animated fadeInRight';
    $scope.bring2ndSlide = function(direction){
        $scope.showSlide1 = false;
        $scope.showSlide2 = true;
        $scope.showSlide3 = false;
        if(direction === "from-left" ){
            $scope.animate2ndSlide = 'animated fadeInLeft';
        }else{
            $scope.animate2ndSlide = 'animated fadeInRight';
        }
    };

    $scope.animate3rdSlide = 'animated fadeInRight';
    $scope.bring3rdSlide = function(direction){
		$scope.showSlide1 = false;
        $scope.showSlide2 = false;
        $scope.showSlide3 = true;
        if(direction === "from-left" ){
            $scope.animate3rdSlide = 'animated fadeInLeft';
        }else{
            $scope.animate3rdSlide = 'animated fadeInRight';
        }
    };




});